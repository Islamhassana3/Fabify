<?php
/**
 * Theme functions and definitions
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'FABIFY_VERSION', '1.0.0' );

add_action( 'after_setup_theme', function () {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'script', 'style' ) );
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'fabify-shop' ),
    ) );
} );

add_action( 'wp_enqueue_scripts', function () {
    // Main stylesheet (style.css with theme header)
    wp_enqueue_style( 'fabify-style', get_stylesheet_uri(), array(), FABIFY_VERSION );

    // Custom stylesheet placed under assets/css/custom.css (from your upload)
    wp_enqueue_style( 'fabify-custom', get_template_directory_uri() . '/assets/css/custom.css', array('fabify-style'), FABIFY_VERSION );

    // Font Awesome (CDN)
    wp_enqueue_style( 'fabify-fontawesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', array(), '6.4.0' );

    // Google Fonts (enqueue in case CSS import is removed)
    wp_enqueue_style( 'fabify-google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap', array(), null );

    // Custom JS
    wp_enqueue_script( 'fabify-custom', get_template_directory_uri() . '/assets/js/custom.js', array(), FABIFY_VERSION, true );
} );

// Basic WooCommerce support (optional - safe to include even if WC not installed)
add_action( 'after_setup_theme', function () {
    add_theme_support( 'woocommerce' );
} );
