// Sample product data
        const sampleProducts = [
            {
                id: 1,
                name: "Wireless Bluetooth Headphones with Noise Cancellation",
                price: 89.99,
                originalPrice: 129.99,
                image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.5,
                reviews: 1242,
                badge: "Hot Deal"
            },
            {
                id: 2,
                name: "Smart Fitness Tracker Watch with Heart Rate Monitor",
                price: 49.99,
                originalPrice: 79.99,
                image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.3,
                reviews: 897,
                badge: "Best Seller"
            },
            {
                id: 3,
                name: "Premium Coffee Maker with Built-in Grinder",
                price: 129.99,
                originalPrice: 199.99,
                image: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.7,
                reviews: 563,
                badge: "New"
            },
            {
                id: 4,
                name: "Ergonomic Office Chair with Lumbar Support",
                price: 199.99,
                originalPrice: 299.99,
                image: "https://images.unsplash.com/photo-1592078615290-033ee584e267?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.6,
                reviews: 721,
                badge: "Sale"
            },
            {
                id: 5,
                name: "4K Ultra HD Action Camera with Waterproof Housing",
                price: 149.99,
                originalPrice: 229.99,
                image: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.4,
                reviews: 432,
                badge: "Limited Offer"
            },
            {
                id: 6,
                name: "Wireless Fast Charging Pad for Smartphones",
                price: 29.99,
                originalPrice: 49.99,
                image: "https://images.unsplash.com/photo-1606220588911-4a4260c1d0c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.2,
                reviews: 287,
                badge: ""
            },
            {
                id: 7,
                name: "Premium Wireless Earbuds with Active Noise Cancelling",
                price: 129.99,
                originalPrice: 179.99,
                image: "https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.8,
                reviews: 945,
                badge: "Editor's Choice"
            },
            {
                id: 8,
                name: "Smart Home Security Camera with Night Vision",
                price: 79.99,
                originalPrice: 119.99,
                image: "https://images.unsplash.com/photo-1593687254727-6323d5b7e5d6?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
                rating: 4.5,
                reviews: 634,
                badge: "Top Rated"
            }
        ];

        // DOM Elements
        const cartSidebar = document.getElementById('cartSidebar');
        const closeCart = document.getElementById('closeCart');
        const overlay = document.getElementById('overlay');
        const cartIcon = document.getElementById('cartIcon');
        const cartItems = document.getElementById('cartItems');
        const cartSubtotal = document.getElementById('cartSubtotal');
        const cartShipping = document.getElementById('cartShipping');
        const cartTax = document.getElementById('cartTax');
        const cartTotal = document.getElementById('cartTotal');
        const cartCount = document.querySelector('.cart-count');
        const toast = document.getElementById('toast');
        const toastMessage = document.getElementById('toastMessage');
        const emptyCartMessage = document.getElementById('emptyCartMessage');
        const featuredProducts = document.getElementById('featuredProducts');
        const dealProducts = document.getElementById('dealProducts');
        const bestSellers = document.getElementById('bestSellers');

        // Cart state
        let cart = [];
        let cartOpen = false;

        // Initialize the page
        function init() {
            renderProducts();
            updateCartUI();
            setupEventListeners();
            initCarousel();
        }

        // Render products to sections
        function renderProducts() {
            renderProductSection(featuredProducts, sampleProducts);
            renderProductSection(dealProducts, sampleProducts.filter(p => p.badge));
            renderProductSection(bestSellers, [...sampleProducts].sort((a, b) => b.reviews - a.reviews));
        }

        // Render product section
        function renderProductSection(container, products) {
            container.innerHTML = '';
            products.forEach(product => {
                const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
                
                const productCard = document.createElement('div');
                productCard.className = 'product-card';
                productCard.innerHTML = `
                    <div class="product-image-container">
                        <img src="${product.image}" alt="${product.name}" class="product-image">
                        ${product.badge ? `<div class="product-badge">${product.badge}</div>` : ''}
                    </div>
                    <div class="product-info">
                        <h3 class="product-title">${product.name}</h3>
                        <div class="product-price">$${product.price}
                            ${product.originalPrice > product.price ? `<span class="product-original-price">$${product.originalPrice}</span>
                            <span class="product-discount">${discount}% off</span>` : ''}
                        </div>
                        <div class="product-rating">
                            <div class="stars">
                                ${generateStars(product.rating)}
                            </div>
                            <span class="rating-count">(${product.reviews})</span>
                        </div>
                        <button class="add-to-cart" onclick="addToCart(${product.id})">
                            <i class="fas fa-shopping-cart"></i> Add to Cart
                        </button>
                    </div>
                `;
                container.appendChild(productCard);
            });
        }

        // Generate star rating HTML
        function generateStars(rating) {
            let stars = '';
            const fullStars = Math.floor(rating);
            const hasHalfStar = rating % 1 !== 0;
            
            for (let i = 0; i < fullStars; i++) {
                stars += '<i class="fas fa-star"></i>';
            }
            
            if (hasHalfStar) {
                stars += '<i class="fas fa-star-half-alt"></i>';
            }
            
            const emptyStars = 5 - Math.ceil(rating);
            for (let i = 0; i < emptyStars; i++) {
                stars += '<i class="far fa-star"></i>';
            }
            
            return stars;
        }

        // Add to cart function
        function addToCart(productId) {
            const product = sampleProducts.find(p => p.id === productId);
            if (!product) return;
            
            // Check if product is already in cart
            const existingItem = cart.find(item => item.id === productId);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    image: product.image,
                    quantity: 1
                });
            }
            
            updateCartUI();
            showToast(`Added ${product.name} to your cart!`);
        }

        // Remove from cart
        function removeFromCart(productId) {
            cart = cart.filter(item => item.id !== productId);
            updateCartUI();
        }

        // Update quantity in cart
        function updateQuantity(productId, newQuantity) {
            if (newQuantity <= 0) {
                removeFromCart(productId);
                return;
            }
            
            const item = cart.find(item => item.id === productId);
            if (item) {
                item.quantity = newQuantity;
                updateCartUI();
            }
        }

        // Update cart UI
        function updateCartUI() {
            // Update cart items
            cartItems.innerHTML = '';
            
            if (cart.length === 0) {
                emptyCartMessage.style.display = 'block';
                cartItems.appendChild(emptyCartMessage);
            } else {
                emptyCartMessage.style.display = 'none';
                
                let subtotal = 0;
                
                cart.forEach(item => {
                    const itemTotal = item.price * item.quantity;
                    subtotal += itemTotal;
                    
                    const cartItem = document.createElement('div');
                    cartItem.className = 'cart-item';
                    cartItem.innerHTML = `
                        <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                        <div class="cart-item-details">
                            <h4 class="cart-item-title">${item.name}</h4>
                            <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                            <div class="cart-item-actions">
                                <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity - 1})">-</button>
                                <input type="number" class="quantity-input" value="${item.quantity}" min="1" onchange="updateQuantity(${item.id}, parseInt(this.value))">
                                <button class="quantity-btn" onclick="updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
                                <button class="remove-btn" onclick="removeFromCart(${item.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    `;
                    cartItems.appendChild(cartItem);
                });
                
                // Calculate totals
                const shipping = subtotal > 0 ? Math.min(20, subtotal * 0.05) : 0;
                const tax = subtotal * 0.08;
                const total = subtotal + shipping + tax;
                
                // Update totals
                cartSubtotal.textContent = subtotal.toFixed(2);
                cartShipping.textContent = shipping.toFixed(2);
                cartTax.textContent = tax.toFixed(2);
                cartTotal.textContent = total.toFixed(2);
            }
            
            // Update cart count
            const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            if (totalItems > 0) {
                cartCount.textContent = totalItems;
                cartCount.style.display = 'flex';
            } else {
                cartCount.style.display = 'none';
            }
        }

        // Toggle cart sidebar
        function toggleCart() {
            cartOpen = !cartOpen;
            cartSidebar.classList.toggle('open', cartOpen);
            overlay.classList.toggle('active', cartOpen);
            document.body.style.overflow = cartOpen ? 'hidden' : 'auto';
        }

        // Show toast notification
        function showToast(message, isError = false) {
            toastMessage.textContent = message;
            toast.classList.add('show');
            if (isError) toast.classList.add('error');
            
            setTimeout(() => {
                toast.classList.remove('show');
                toast.classList.remove('error');
            }, 3000);
        }

        // Initialize carousel
        function initCarousel() {
            const slides = document.querySelectorAll('.hero-slide');
            const indicators = document.querySelectorAll('.indicator');
            let currentSlide = 0;
            
            function showSlide(index) {
                slides.forEach(slide => slide.classList.remove('active'));
                indicators.forEach(indicator => indicator.classList.remove('active'));
                
                slides[index].classList.add('active');
                indicators[index].classList.add('active');
                currentSlide = index;
            }
            
            // Auto advance slides
            setInterval(() => {
                currentSlide = (currentSlide + 1) % slides.length;
                showSlide(currentSlide);
            }, 5000);
            
            // Manual slide control
            indicators.forEach((indicator, index) => {
                indicator.addEventListener('click', () => {
                    showSlide(index);
                });
            });
        }

        // Setup event listeners
        function setupEventListeners() {
            // Cart icon click
            cartIcon.addEventListener('click', (e) => {
                e.preventDefault();
                toggleCart();
            });
            
            // Close cart
            closeCart.addEventListener('click', () => {
                cartOpen = false;
                cartSidebar.classList.remove('open');
                overlay.classList.remove('active');
                document.body.style.overflow = 'auto';
            });
            
            overlay.addEventListener('click', () => {
                cartOpen = false;
                cartSidebar.classList.remove('open');
                overlay.classList.remove('active');
                document.body.style.overflow = 'auto';
            });
        }

        // Initialize the application
        document.addEventListener('DOMContentLoaded', () => {
            init();
        });

        // Expose functions to global scope
        window.addToCart = addToCart;
        window.removeFromCart = removeFromCart;
        window.updateQuantity = updateQuantity;
        window.toggleCart = toggleCart;