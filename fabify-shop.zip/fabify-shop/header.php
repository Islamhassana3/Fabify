<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header" role="banner">
  <div class="container">
    <nav class="navbar" role="navigation" aria-label="<?php esc_attr_e( 'Primary', 'fabify-shop' ); ?>">
      <a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <i class="fas fa-crown"></i> <?php bloginfo('name'); ?>
      </a>
      <?php
        wp_nav_menu( array(
          'theme_location' => 'primary',
          'container'      => 'div',
          'container_class'=> 'nav-links',
          'fallback_cb'    => false
        ) );
      ?>
    </nav>
  </div>
</header>
<main id="content" class="site-content">
