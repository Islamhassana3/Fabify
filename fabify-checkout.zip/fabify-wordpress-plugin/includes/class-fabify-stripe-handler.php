<?php

/**
 * Stripe Handler for Fabify Checkout
 */

class Fabify_Stripe_Handler {
    
    private $secret_key;
    private $publishable_key;
    private $webhook_secret;
    
    public function __construct() {
        $this->init_stripe();
    }
    
    private function init_stripe() {
        // Get Stripe keys from WordPress options or environment
        $this->secret_key = get_option('fabify_stripe_secret_key', '');
        $this->publishable_key = get_option('fabify_stripe_publishable_key', '');
        $this->webhook_secret = get_option('fabify_stripe_webhook_secret', '');
        
        // If keys are not set, try to get from environment variables
        if (empty($this->secret_key)) {
            $this->secret_key = getenv('STRIPE_SECRET_KEY') ?: '';
        }
        if (empty($this->publishable_key)) {
            $this->publishable_key = getenv('STRIPE_PUBLISHABLE_KEY') ?: '';
        }
        if (empty($this->webhook_secret)) {
            $this->webhook_secret = getenv('STRIPE_WEBHOOK_SECRET') ?: '';
        }
        
        // Include Stripe PHP library (should be installed via composer)
        if (class_exists('\Stripe\Stripe')) {
            \Stripe\Stripe::setApiKey($this->secret_key);
        }
    }
    
    /**
     * Create payment intent for an order
     */
    public function create_payment_intent($order) {
        if (!class_exists('\Stripe\PaymentIntent')) {
            return new WP_Error('stripe_not_loaded', 'Stripe library not loaded', array('status' => 500));
        }
        
        try {
            $amount = $order->get_total() * 100; // Convert to cents
            $currency = $order->get_currency();
            
            $payment_intent = \Stripe\PaymentIntent::create([
                'amount' => $amount,
                'currency' => strtolower($currency),
                'metadata' => [
                    'order_id' => $order->get_id(),
                    'order_key' => $order->get_order_key(),
                ],
                'automatic_payment_methods' => [
                    'enabled' => true,
                ],
            ]);
            
            // Store payment intent ID in order
            $order->update_meta_data('_stripe_payment_intent_id', $payment_intent->id);
            $order->save();
            
            return array(
                'client_secret' => $payment_intent->client_secret,
                'payment_intent_id' => $payment_intent->id,
            );
            
        } catch (Exception $e) {
            return new WP_Error('stripe_error', $e->getMessage(), array('status' => 400));
        }
    }
    
    /**
     * Confirm payment for an order
     */
    public function confirm_payment($order, $payment_intent_id) {
        try {
            $payment_intent = \Stripe\PaymentIntent::retrieve($payment_intent_id);
            
            if ($payment_intent->status === 'succeeded') {
                // Update order status
                $order->payment_complete($payment_intent_id);
                $order->add_order_note('Payment completed via Stripe. Payment Intent ID: ' . $payment_intent_id);
                
                // Store transaction ID
                $order->set_transaction_id($payment_intent->charges->data[0]->id);
                $order->save();
                
                return array(
                    'success' => true,
                    'status' => $order->get_status(),
                    'order_id' => $order->get_id(),
                );
            } else {
                return new WP_Error('payment_failed', 'Payment not successful', array('status' => 400));
            }
            
        } catch (Exception $e) {
            return new WP_Error('stripe_error', $e->getMessage(), array('status' => 400));
        }
    }
    
    /**
     * Handle Stripe webhooks
     */
    public function handle_webhook($request) {
        if (empty($this->webhook_secret)) {
            return new WP_Error('no_webhook_secret', 'Webhook secret not configured', array('status' => 500));
        }
        
        $payload = $request->get_body();
        $sig_header = $request->get_header('Stripe-Signature');
        
        try {
            $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $this->webhook_secret);
        } catch (Exception $e) {
            return new WP_Error('invalid_signature', 'Invalid signature', array('status' => 400));
        }
        
        switch ($event->type) {
            case 'payment_intent.succeeded':
                return $this->handle_payment_intent_succeeded($event->data->object);
                
            case 'payment_intent.payment_failed':
                return $this->handle_payment_intent_failed($event->data->object);
                
            case 'payment_intent.canceled':
                return $this->handle_payment_intent_canceled($event->data->object);
                
            default:
                return array('received' => true);
        }
    }
    
    /**
     * Handle successful payment intent
     */
    private function handle_payment_intent_succeeded($payment_intent) {
        $order_id = $payment_intent->metadata->order_id ?? null;
        
        if ($order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                $order->payment_complete($payment_intent->id);
                $order->add_order_note('Payment completed via Stripe webhook. Payment Intent ID: ' . $payment_intent->id);
                
                // Store transaction ID
                if (isset($payment_intent->charges->data[0])) {
                    $order->set_transaction_id($payment_intent->charges->data[0]->id);
                }
                $order->save();
            }
        }
        
        return array('status' => 'success');
    }
    
    /**
     * Handle failed payment intent
     */
    private function handle_payment_intent_failed($payment_intent) {
        $order_id = $payment_intent->metadata->order_id ?? null;
        
        if ($order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                $order->update_status('failed', 'Payment failed via Stripe. Reason: ' . $payment_intent->last_payment_error->message ?? 'Unknown error');
                $order->add_order_note('Payment failed via Stripe webhook. Payment Intent ID: ' . $payment_intent->id);
            }
        }
        
        return array('status' => 'failed');
    }
    
    /**
     * Handle canceled payment intent
     */
    private function handle_payment_intent_canceled($payment_intent) {
        $order_id = $payment_intent->metadata->order_id ?? null;
        
        if ($order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                $order->update_status('cancelled', 'Payment canceled via Stripe. Payment Intent ID: ' . $payment_intent->id);
                $order->add_order_note('Payment canceled via Stripe webhook');
            }
        }
        
        return array('status' => 'canceled');
    }
    
    /**
     * Get Stripe publishable key for frontend
     */
    public function get_publishable_key() {
        return $this->publishable_key;
    }
    
    /**
     * Refund payment
     */
    public function refund_payment($order, $amount = null) {
        try {
            $payment_intent_id = $order->get_meta('_stripe_payment_intent_id', true);
            
            if (!$payment_intent_id) {
                return new WP_Error('no_payment_intent', 'No payment intent found for this order', array('status' => 400));
            }
            
            $refund_data = [
                'payment_intent' => $payment_intent_id,
            ];
            
            if ($amount && $amount > 0) {
                $refund_data['amount'] = $amount * 100; // Convert to cents
            }
            
            $refund = \Stripe\Refund::create($refund_data);
            
            // Create refund in WooCommerce
            $refund_amount = $refund->amount / 100; // Convert back to currency
            $order->create_order_refund(array(
                'amount' => $refund_amount,
                'reason' => 'Refund via Stripe',
            ));
            
            $order->add_order_note('Refund processed via Stripe. Refund ID: ' . $refund->id);
            
            return array(
                'success' => true,
                'refund_id' => $refund->id,
                'amount' => $refund_amount,
            );
            
        } catch (Exception $e) {
            return new WP_Error('stripe_error', $e->getMessage(), array('status' => 400));
        }
    }
    
    /**
     * Create setup intent for saved payment methods
     */
    public function create_setup_intent($customer_id) {
        try {
            $setup_intent = \Stripe\SetupIntent::create([
                'customer' => $customer_id,
                'payment_method_types' => ['card'],
            ]);
            
            return array(
                'client_secret' => $setup_intent->client_secret,
                'setup_intent_id' => $setup_intent->id,
            );
            
        } catch (Exception $e) {
            return new WP_Error('stripe_error', $e->getMessage(), array('status' => 400));
        }
    }
}