<?php
/**
 * Plugin Name: Fabify Checkout
 * Description: Custom checkout functionality for Fabify marketplace
 * Version: 1.0.0
 * Author: Fabify Team
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('FABIFY_CHECKOUT_VERSION', '1.0.0');
define('FABIFY_CHECKOUT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FABIFY_CHECKOUT_PLUGIN_URL', plugin_dir_url(__FILE__));

class FabifyCheckout {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }
    
    public function init() {
        // Initialize plugin
        $this->load_dependencies();
        $this->setup_hooks();
    }
    
    private function load_dependencies() {
        // Load any required files
        require_once FABIFY_CHECKOUT_PLUGIN_DIR . 'includes/class-fabify-stripe-handler.php';
    }
    
    private function setup_hooks() {
        // Setup WordPress hooks
        add_filter('woocommerce_rest_prepare_product', array($this, 'prepare_product_data'), 10, 3);
        add_action('woocommerce_before_checkout_process', array($this, 'validate_checkout'));
    }
    
    public function register_rest_routes() {
        // Register custom REST API endpoints
        
        // Cart endpoints
        register_rest_route('wc/v3', '/cart', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_cart'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('wc/v3', '/cart/add', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_to_cart'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('wc/v3', '/cart/update', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_cart_item'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('wc/v3', '/cart/remove', array(
            'methods' => 'POST',
            'callback' => array($this, 'remove_from_cart'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('wc/v3', '/cart/clear', array(
            'methods' => 'POST',
            'callback' => array($this, 'clear_cart'),
            'permission_callback' => '__return_true'
        ));
        
        // Coupon endpoints
        register_rest_route('wc/v3', '/cart/apply-coupon', array(
            'methods' => 'POST',
            'callback' => array($this, 'apply_coupon'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('wc/v3', '/cart/remove-coupon', array(
            'methods' => 'POST',
            'callback' => array($this, 'remove_coupon'),
            'permission_callback' => '__return_true'
        ));
        
        // Shipping endpoints
        register_rest_route('wc/v3', '/shipping/calculate', array(
            'methods' => 'POST',
            'callback' => array($this, 'calculate_shipping'),
            'permission_callback' => '__return_true'
        ));
        
        // Checkout endpoints
        register_rest_route('wc/v3', '/checkout', array(
            'methods' => 'POST',
            'callback' => array($this, 'process_checkout'),
            'permission_callback' => '__return_true'
        ));
        
        // Stripe payment endpoints
        register_rest_route('wc/v3', '/orders/(?P<id>\d+)/stripe_payment_intent', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_stripe_payment_intent'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('wc/v3', '/orders/(?P<id>\d+)/stripe_confirm_payment', array(
            'methods' => 'POST',
            'callback' => array($this, 'confirm_stripe_payment'),
            'permission_callback' => '__return_true'
        ));
        
        // Webhook endpoint
        register_rest_route('fabify/v1', '/stripe/webhook', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_stripe_webhook'),
            'permission_callback' => '__return_true'
        ));
    }
    
    // Cart functions
    public function get_cart(WP_REST_Request $request) {
        $cart = WC()->cart;
        
        $cart_items = array();
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $product = $cart_item['data'];
            $cart_items[] = array(
                'key' => $cart_item_key,
                'id' => $product->get_id(),
                'name' => $product->get_name(),
                'quantity' => $cart_item['quantity'],
                'price' => $product->get_price(),
                'total' => $cart_item['line_total'],
                'image' => array(
                    'src' => wp_get_attachment_image_url($product->get_image_id(), 'thumbnail'),
                    'alt' => $product->get_name()
                )
            );
        }
        
        return array(
            'items' => $cart_items,
            'totals' => array(
                'subtotal' => $cart->get_subtotal(),
                'total' => $cart->get_total(),
                'shipping_total' => $cart->get_shipping_total(),
                'discount_total' => $cart->get_discount_total()
            ),
            'shipping_methods' => $this->get_available_shipping_methods(),
            'payment_methods' => $this->get_available_payment_methods()
        );
    }
    
    public function add_to_cart(WP_REST_Request $request) {
        $product_id = $request->get_param('product_id');
        $quantity = $request->get_param('quantity') ?: 1;
        
        $cart = WC()->cart;
        $cart->add_to_cart($product_id, $quantity);
        
        return $this->get_cart($request);
    }
    
    public function update_cart_item(WP_REST_Request $request) {
        $cart_item_key = $request->get_param('key');
        $quantity = $request->get_param('quantity');
        
        $cart = WC()->cart;
        $cart->set_quantity($cart_item_key, $quantity);
        
        return $this->get_cart($request);
    }
    
    public function remove_from_cart(WP_REST_Request $request) {
        $cart_item_key = $request->get_param('key');
        
        $cart = WC()->cart;
        $cart->remove_cart_item($cart_item_key);
        
        return $this->get_cart($request);
    }
    
    public function clear_cart(WP_REST_Request $request) {
        $cart = WC()->cart;
        $cart->empty_cart();
        
        return $this->get_cart($request);
    }
    
    // Coupon functions
    public function apply_coupon(WP_REST_Request $request) {
        $coupon_code = $request->get_param('coupon_code');
        
        $cart = WC()->cart;
        $cart->apply_coupon($coupon_code);
        
        return $this->get_cart($request);
    }
    
    public function remove_coupon(WP_REST_Request $request) {
        $coupon_code = $request->get_param('coupon_code');
        
        $cart = WC()->cart;
        $cart->remove_coupon($coupon_code);
        
        return $this->get_cart($request);
    }
    
    // Shipping functions
    private function get_available_shipping_methods() {
        $shipping_zones = WC_Shipping_Zones::get_zones();
        $methods = array();
        
        foreach ($shipping_zones as $zone) {
            foreach ($zone->get_shipping_methods() as $method) {
                $methods[] = array(
                    'id' => $method->get_id(),
                    'title' => $method->get_title(),
                    'description' => $method->get_method_description(),
                    'cost' => $method->get_cost()
                );
            }
        }
        
        return $methods;
    }
    
    public function calculate_shipping(WP_REST_Request $request) {
        $country = $request->get_param('country');
        $state = $request->get_param('state');
        $postcode = $request->get_param('postcode');
        $city = $request->get_param('city');
        
        $cart = WC()->cart;
        $cart->calculate_shipping();
        
        return array(
            'shipping_methods' => $this->get_available_shipping_methods(),
            'shipping_total' => $cart->get_shipping_total()
        );
    }
    
    // Payment functions
    private function get_available_payment_methods() {
        $gateways = WC()->payment_gateways->get_available_payment_gateways();
        $methods = array();
        
        foreach ($gateways as $gateway) {
            $methods[] = array(
                'id' => $gateway->get_id(),
                'title' => $gateway->get_title(),
                'description' => $gateway->get_description()
            );
        }
        
        return $methods;
    }
    
    // Checkout functions
    public function process_checkout(WP_REST_Request $request) {
        $data = $request->get_json_params();
        
        // Create order
        $order = wc_create_order();
        
        // Set billing and shipping
        $order->set_billing_first_name($data['billing']['first_name']);
        $order->set_billing_last_name($data['billing']['last_name']);
        $order->set_billing_email($data['billing']['email']);
        $order->set_billing_phone($data['billing']['phone']);
        $order->set_billing_address_1($data['billing']['address_1']);
        $order->set_billing_city($data['billing']['city']);
        $order->set_billing_state($data['billing']['state']);
        $order->set_billing_postcode($data['billing']['postcode']);
        $order->set_billing_country($data['billing']['country']);
        
        $order->set_shipping_first_name($data['shipping']['first_name']);
        $order->set_shipping_last_name($data['shipping']['last_name']);
        $order->set_shipping_address_1($data['shipping']['address_1']);
        $order->set_shipping_city($data['shipping']['city']);
        $order->set_shipping_state($data['shipping']['state']);
        $order->set_shipping_postcode($data['shipping']['postcode']);
        $order->set_shipping_country($data['shipping']['country']);
        
        // Add products to order
        foreach ($data['line_items'] as $item) {
            $order->add_product(wc_get_product($item['product_id']), $item['quantity']);
        }
        
        // Set payment method
        $order->set_payment_method($data['payment_method']);
        $order->set_payment_method_title($data['payment_method_title']);
        
        // Calculate totals
        $order->calculate_totals();
        
        // Save order
        $order->save();
        
        return $order->get_data();
    }
    
    // Stripe functions
    public function create_stripe_payment_intent(WP_REST_Request $request) {
        $order_id = $request->get_param('id');
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return new WP_Error('invalid_order', 'Order not found', array('status' => 404));
        }
        
        $stripe_handler = new Fabify_Stripe_Handler();
        return $stripe_handler->create_payment_intent($order);
    }
    
    public function confirm_stripe_payment(WP_REST_Request $request) {
        $order_id = $request->get_param('id');
        $payment_intent_id = $request->get_param('payment_intent_id');
        $order = wc_get_order($order_id);
        
        if (!$order) {
            return new WP_Error('invalid_order', 'Order not found', array('status' => 404));
        }
        
        $stripe_handler = new Fabify_Stripe_Handler();
        return $stripe_handler->confirm_payment($order, $payment_intent_id);
    }
    
    public function handle_stripe_webhook(WP_REST_Request $request) {
        $stripe_handler = new Fabify_Stripe_Handler();
        return $stripe_handler->handle_webhook($request);
    }
    
    // Product data preparation
    public function prepare_product_data($response, $product, $request) {
        $data = $response->get_data();
        
        // Add custom fields if needed
        $data['custom_fields'] = array(
            'badge' => get_post_meta($product->get_id(), '_badge', true),
            'shipping_info' => get_post_meta($product->get_id(), '_shipping_info', true)
        );
        
        $response->set_data($data);
        return $response;
    }
    
    // Checkout validation
    public function validate_checkout() {
        // Add custom validation logic
        if (!WC()->cart->is_empty()) {
            // Validate cart items
            foreach (WC()->cart->get_cart() as $cart_item) {
                $product = $cart_item['data'];
                if (!$product->is_in_stock()) {
                    wc_add_notice(sprintf('Product "%s" is out of stock.', $product->get_name()), 'error');
                }
            }
        }
    }
}

// Initialize the plugin
new FabifyCheckout();

// Activation hook
register_activation_hook(__FILE__, function() {
    // Create necessary database tables or options
    add_option('fabify_checkout_version', FABIFY_CHECKOUT_VERSION);
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    // Cleanup if needed
    delete_option('fabify_checkout_version');
});