Add your hero images here: hero1.jpg, hero2.jpg, hero3.jpg (1920x1080px recommended)
